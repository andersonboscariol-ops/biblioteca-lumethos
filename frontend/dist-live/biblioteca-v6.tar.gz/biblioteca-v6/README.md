# 🏛️ Biblioteca Lumethos — Restore Point v6

**Versão:** v6
**Data:** 19/07/2026 10:57 BRT
**PM2:** biblioteca (id 20, restart #26)

## O que está incluído

| Arquivo | Caminho original | Descrição |
|---------|-----------------|-----------|
| `frontend/app.html` | `/var/www/biblioteca/frontend/dist/app.html` | App principal (login, grid, modal, css) |
| `frontend/login.html` | `/var/www/biblioteca/frontend/dist/login.html` | Tela de login |
| `backend/src/index.js` | `/var/www/biblioteca/backend/src/index.js` | Servidor Express (middleware covers, thumbnail proxy) |

## Estado das Covers
- 451 covers locais (427 .jpg + 9 .webp + 24 symlinks → capa-generica.jpg)
- Comprimidas: `-resize 150x> -quality 50`
- Proxy timeout: 3000ms
- ZERO requisições ao Google Drive no carregamento de categorias

## Últimas Modificações
1. CSS mobile com 4 colunas (768px) / 3 colunas (480px)
2. Imagens com `height: auto` + `object-fit: cover` — preenchem o card na proporção
3. Títulos em 11px, quebra em até 2 linhas, centralizados
4. Login mobile: faixa azul removida, botão instituto flutuante no canto
5. Login mobile: layout empilhado com display:block

## Para Restaurar
```bash
cp backup/frontend/app.html /var/www/biblioteca/frontend/dist/app.html
cp backup/frontend/login.html /var/www/biblioteca/frontend/dist/login.html
cp backup/backend/src/index.js /var/www/biblioteca/backend/src/index.js
pm2 restart biblioteca --update-env
```

## Hash dos Arquivos

```
f02dfcef6adbfa118f6383ef97af36a2  /root/.openclaw/workspace-juju/backups/biblioteca-v6/frontend/app.html
65e39c6cc44445b4bc664b5a97094367  /root/.openclaw/workspace-juju/backups/biblioteca-v6/frontend/login.html
1baade37fec3920ecbabcb64250a3c5a  /root/.openclaw/workspace-juju/backups/biblioteca-v6/backend/src/index.js
```

> Gerado por Juju 🤖 em 19/07/2026 10:57 BRT
